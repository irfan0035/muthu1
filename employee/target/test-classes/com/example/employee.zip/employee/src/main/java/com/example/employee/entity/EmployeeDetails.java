package com.example.employee.entity;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor

@Entity
@Table(name="employee")
public class EmployeeDetails extends AuditEntity{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;
    @Column(name="employee_name")
    private String name;
    @Column(name="salary")
    private long salary;
    @Column(name="address")
    private String address;
    @Column(name="gender")
    private String gender;

}
