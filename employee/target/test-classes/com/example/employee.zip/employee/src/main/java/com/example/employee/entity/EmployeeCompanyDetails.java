package com.example.employee.entity;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name="company_details")
public class EmployeeCompanyDetails extends AuditEntity{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
   private long id;
    @Column(name="emp_id")
    private long employeeId;
    @Column(name="comapany_name")
    private String companyName;
    @Column(name="designation")
    private String designation;
    @Column(name="emp_salary")
    private long employeeSalary;

}
