package com.example.employee.controller;

import com.example.employee.entity.EmployeeDetails;
import com.example.employee.service.EmployeeService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("employee")
public class EmployeeController {


    private final EmployeeService employeeService;

    public EmployeeController(EmployeeService employeeService) {
        this.employeeService = employeeService;
    }

    @GetMapping("/details")
    public EmployeeDetails getAllComments(){
        return employeeService.getEmployeeDetails();
    }

    @GetMapping("/hello")
    public String getHello(){
        return "hello muthu";
    }

}
