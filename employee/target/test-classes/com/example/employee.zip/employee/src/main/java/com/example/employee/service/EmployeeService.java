package com.example.employee.service;

import com.example.employee.entity.EmployeeDetails;

import java.util.Optional;

public interface EmployeeService {

    EmployeeDetails getEmployeeDetails();
}
