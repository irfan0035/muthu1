package com.example.employee.service.impl;

import com.example.employee.entity.EmployeeDetails;
import com.example.employee.repository.EmployeeRepository;
import com.example.employee.service.EmployeeService;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class EmployeeServiceImpl implements EmployeeService{

    private final EmployeeRepository employeeRepository;

    public EmployeeServiceImpl(EmployeeRepository employeeRepository) {
        this.employeeRepository = employeeRepository;
    }

    @Override
    public EmployeeDetails getEmployeeDetails() {
        return employeeRepository.getEmployeeDetailsById(1L);
    }
}
